This application highlights the features and functionality of the Oracle Application Express Interactive Grid. The interactive grid sample pages highlight the following declarative features.

Installation Steps
------------------------------------
1. Download the .zip file in this directory
2. Navigate to App Builder -> Import
3. Drag and drop the application .zip file and click Next
4. Leave the defaults as they are, then continue through the remaining steps in the wizard to finish installing the application
