# REST Data Source Plug-In examples

This directory contains examples for REST Data Source Plug-Ins.

- Example plug-in which shows how to implement pagination for a REST API using a fixed page size and a page number parameter.
